<?php if(!defined('LS_ROOT_FILE')) {  header('HTTP/1.0 403 Forbidden'); exit; } ?>
<script type="text/html" id="tmpl-slider-group-placeholder">
<div class="item scale0">
	<div class="preview">
		<div class="no-preview">
			<?php _e('No Preview', 'LayerSlider') ?>
		</div>
	</div>
</div>
</script>